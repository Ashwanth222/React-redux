export const increment = "INCREMENT";
export const decrement = "DECREMENT";
export const reset = "RESET";
export const double = "DOUBLEINCREMENT";
export const decreased = "DOUBLEDECREMENT";

export const incrementAction = () => ({ type: increment });
export const decrementAction = () => ({ type: decrement });
export const resetAction = () => ({ type: reset });

export const doubleIncrement = () => ({ type: double });
export const doubleDecrement = () => ({ type: decreased });
